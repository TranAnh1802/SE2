package jersey.model;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Orders {
	private int ID;
	private String orderDate;
	private String amount;
	private int CustomerId;

	public Orders() {
		super();
	}

	public Orders(int iD, String orderDate, String amount, int customerId) {
		super();
		ID = iD;
		this.orderDate = orderDate;
		this.amount = amount;
		CustomerId = customerId;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public int getCustomerId() {
		return CustomerId;
	}

	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}
	
}
