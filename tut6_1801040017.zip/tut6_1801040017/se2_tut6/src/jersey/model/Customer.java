package jersey.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Customer {
	private int ID;
	private String name;
	private String country;
	private String phone;

	public Customer() {
		super();
	}

	public Customer(int iD, String name, String country, String phone) {
		super();
		ID = iD;
		this.name = name;
		this.country = country;
		this.phone = phone;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}
