package jersey.service;

import java.util.ArrayList;
import java.util.List;
import jersey.model.Customer;

public class CustomerService {
	public List<Customer> getAllCustomer() {
		Customer c1 = new Customer (1,"Minh Thao","Viet Nam","09347922222");
		Customer c2 = new Customer (2,"Do Hieu","Viet Nam","0930333333");
		List<Customer> list = new ArrayList<Customer>();
		list.add(c1);
		list.add(c2);
		return list;
	}

}
