package jersey.service;

import java.util.ArrayList;
import java.util.List;

import jersey.model.Supplier;

public class SupplierService {
	public List<Supplier> getAllSupplier(){
		Supplier s1 = new Supplier(1,"AAA","092922222");
		Supplier s2 = new Supplier(2,"BBB","07927929329");
		List<Supplier> list = new ArrayList<Supplier>();
		list.add(s1);
		list.add(s2);
		return list;
		
	}


}
