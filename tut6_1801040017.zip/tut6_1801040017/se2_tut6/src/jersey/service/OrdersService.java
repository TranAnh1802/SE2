package jersey.service;
import java.util.ArrayList;
import java.util.List;

import jersey.model.Orders;
public class OrdersService {
	public List<Orders> getAllOrders(){
		Orders o1 = new Orders (1,"2021-12-03","$230000",1);
		Orders o2 = new Orders (2,"2021-02-12","$130000",2);
		List<Orders> list = new ArrayList<Orders>();
		list.add(o1);
		list.add(o2);
		return list;
	}
	

}
