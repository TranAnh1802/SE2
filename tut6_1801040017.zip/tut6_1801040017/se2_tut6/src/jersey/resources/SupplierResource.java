package jersey.resources;

import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import jersey.model.Supplier;
import jersey.service.SupplierService;
import javax.ws.rs.core.MediaType;
	
@Path("/supplier")
public class SupplierResource{
	SupplierService  supplier =  new SupplierService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Supplier> getSupplier(){
		return supplier.getAllSupplier();

			
}
}
