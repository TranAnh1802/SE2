package jersey.resources;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import jersey.model.Orders;
import jersey.service.OrdersService;

@Path("/orders")
public class OrdersResource{
	OrdersService orderService = new OrdersService();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Orders> getSupplier(){
		return orderService.getAllOrders();
}

}
