package tut11_se2.ex3_Mankind;

public class Worker extends Human {
	private double workHoursPerDay;
	private double weekSalary;
	
	public Worker(String firstName, String lastName, double weekSalary, double workHoursPerDay) {
		super(firstName, lastName);
		this.setWeekSalary(weekSalary);
		this.setWorkHoursPerDay(workHoursPerDay);
		
	}
	public double getWeekSalary() {
		return this.weekSalary;
	}
	protected void setWeekSalary(double weekSalary) {
		if(weekSalary <10) {
			throw new IllegalArgumentException("Expected value mismatch!Argument:weekSalary");
		}
		this.weekSalary = weekSalary;
	}
	public double getWorkHousrsPerDay() {
		return this.workHoursPerDay;
	}
	protected void setWorkHoursPerDay(double workingHours) {
		if (workingHours <1 || workingHours >12) {
			throw new IllegalArgumentException("Expected value mismatch!Argument: workHoursPerDay");
		}
		this.workHoursPerDay = workingHours;
	}
	
	public  double getSalaryPerHour() {
		return this.weekSalary/(this.workHoursPerDay*5);
	}
	@Override 
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(super.toString()).append(System.lineSeparator())
		.append("Week Salary: ").append(this.getWeekSalary()).append(System.lineSeparator())
		.append("Hours per day: ").append(this.getWorkHousrsPerDay()).append(System.lineSeparator())
		.append("Salary per hour: ").append(this.getSalaryPerHour());
		return sb.toString();
	}
}
