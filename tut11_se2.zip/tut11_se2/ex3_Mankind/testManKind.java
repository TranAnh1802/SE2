package tut11_se2.ex3_Mankind;

import java.util.Scanner;

public class testManKind {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String student = sc.nextLine();
		String [] s = student.split(" ");
		String first = s[0];
		String last = s[1];
		String n = s[2];
		Student st = new Student(first, last, n);
		
		String worker = sc.nextLine();
		String[] w = worker.split(" ");
		String f  = w[0];
		String l = w[1];
		double salary =Double.parseDouble(w[2]);
		double hours = Double.parseDouble(w[3]);
		Worker wk = new Worker(f, l, salary,hours);
		System.out.println(st.toString());
		System.out.println(wk.toString());
	}
}
