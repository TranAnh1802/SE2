package tut11_se2.ex1_Person;

public class Person {
	private String name;
	private Integer age;
	public String getName() {
		return name;
	}
	protected void setName(String name) throws IllegalArgumentException{
		if(name.length()< 3) {
			throw new IllegalArgumentException("Name's lenght should not be less than 3 symbols!");
		}
			this.name = name;
		}
		
	public Integer getAge() {
		return age;
	}
	protected void setAge(int age) throws IllegalArgumentException{
		if(age<1) {
			throw new IllegalArgumentException("Age must be positive");
		}
		this.age = age;
	}
	public Person(String name, Integer age) {
		super();
		this.setName(name);
		this.setAge(age);
	}
	@Override 
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(String.format("Person name: %s, Age:%d", this.getName(),this.getAge()));
		return sb.toString();
	}
	
	
}
