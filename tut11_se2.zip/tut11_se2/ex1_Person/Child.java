package tut11_se2.ex1_Person;

public class Child  extends Person {

	public Child(String name, int age) {
		super(name, age);
	}
	@Override 
	public void setAge(int age) throws IllegalArgumentException{
		if(age >15) {
			throw new IllegalArgumentException("Child's age must be less than 15!");
			
		}
		super.setAge(age);
	}
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(String.format("Child name: %s, Age:%d", this.getName(),this.getAge()));
		return sb.toString();
	}
}
