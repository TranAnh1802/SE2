package tut11_se2.ex1_Person;

import java.util.Scanner;

public class TestPerson {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name: ");
		String name = sc.nextLine();
		System.out.println("enter age: ");
		int age = Integer.valueOf(sc.nextLine());
		sc.close();
		try {
			Child child = new Child(name, age);
			System.out.println(child.toString());
			String personClassName = Person.class.getSimpleName();
			String childClassName = Child.class.getSimpleName();
			
		}catch(IllegalArgumentException ex) {
			System.out.println(ex.getMessage());
		}
	}
}
