package tut10_se2.bridge.remotes;

import tut10_se2.bridge.devices.Device;

public class AdvancedRemote extends BasicRemote {

    public AdvancedRemote(Device device) {
        super.device = device;
    }

    //TO-DO: Implement the mute() method
    public void mute() {
    	//Display the current volume status is 'mute'
         System.out.println("AdvancedRemote: volume status is mute");
        //Set the volume to 0
        device.setVolume(0);
    }
}
