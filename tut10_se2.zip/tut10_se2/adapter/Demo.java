package tut10_se2.adapter;

import tut10_se2.adapter.adapter.SquarePegAdapter;
import tut10_se2.adapter.round.RoundHole;
import tut10_se2.adapter.round.RoundPeg;
import tut10_se2.adapter.square.SquarePeg;

/**
 * Somewhere in client code...
 */
public class Demo {
	public static void main(String[] args) {
		//TO-DO: Create 2 instances of RoundHole and RoundPeg with same radius
		RoundHole rh = new RoundHole(5);
		RoundPeg rp = new RoundPeg(5);
		//TO-DO: If RoundHole instance can "fits" with RoundPeg instance => show a message
		if(rh.fits(rp)) {
			System.out.println("Roundpeg fit RoundHole.");
		}
		//TO-DO: Create 2 instances of SquarePeg with 2 different widths
		SquarePeg sp1 = new SquarePeg(3);
		SquarePeg sp2 = new SquarePeg(9);
		//Note: You can't make RoundHole instance "fit" with SquarePeg instance
		//Therefore, we need to use Adapter for solving the problem.
		//TO-DO: Create 2 corresponding instances of SquarePegAdapter  
		SquarePegAdapter spa1 = new SquarePegAdapter(sp1);
		SquarePegAdapter spa2 = new SquarePegAdapter(sp2);
		//TO-DO: If the RoundHole instance can "fits" with "small" RoundPegAdapter instance 
		//show a suitable message
	 if(rh.fits(spa1)){
		 System.out.println("SquarePeg fit RoundHole");
	 }
		//TO-DO: If the RoundHole instance can not "fits" with "big" RoundPegAdapter instance 
		//show a suitable message
	 if(!rh.fits(spa2)) {
		 System.out.println("SquarePeg does not fit into RoundHole");
	 }
	}
}