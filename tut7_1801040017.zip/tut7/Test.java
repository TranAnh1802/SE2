package tut7;

public class Test {
	public static void main(String[] args) {
		BagInterface<String> bookBag = new ArrayBag<>();
		// interface .......arraybag
		System.out.println("bookBag: ");
		bookBag.add("SE2");
		bookBag.add("IWS");
		bookBag.add("SQA");
		bookBag.add("IWS");
		bookBag.add("REQ");
		bookBag.add("DBS");
		bookBag.add("SAD");
		System.out.println("Check bookBag Empty:" + bookBag.isEmpty());
		System.out.println("Get Current Size:" +bookBag.getCurrentSize());
		System.out.println("Get Frequency of IWS: " + bookBag.getFrequencyOf("IWS"));
		System.out.println("Check whether bookBag contains SE1 or not:" + bookBag.contains("SE1"));
		System.out.println("Remove unspecified " + bookBag.remove());
		System.out.println("Remove entry SWA:" + bookBag.remove("SWA"));
		System.out.println("Curreny size: " + bookBag.getCurrentSize());
		System.out.println("Display all entries of bookBag: "+ bookBag.toString());
		System.out.println("mobileBag: ");
		BagInterface<String> mobileBag = new ArrayBag<>();
		mobileBag.add("Iphone5");
		mobileBag.add("Iphone6");
		mobileBag.add("Iphone7");
		mobileBag.add("Iphone8");
		mobileBag.add("Iphone10");
		mobileBag.add("Iphone11");
		mobileBag.add("Iphone12");
		System.out.println("Get Current Size:" +mobileBag.getCurrentSize());
		System.out.println("Get Frequency of Iphone7: " + mobileBag.getFrequencyOf("Iphone7"));
		System.out.println("Check whether mobileBag contains Iphone5s or not:" + mobileBag.contains("Iphone5S"));
		System.out.println("Remove unspecified " + mobileBag.remove());
		System.out.println("Remove entry Iphone5:" + mobileBag.remove("Iphone5"));
		System.out.println("Curreny size: " + mobileBag.getCurrentSize());
		System.out.println("Display all entries of mobileBag: "+ mobileBag.toString());
		System.out.println("Clear all entries in mobileBag.");
		mobileBag.clear();
		System.out.println("Check mobileBag is empty or not:" + mobileBag.isEmpty());
		
		
		
		
	}

}
